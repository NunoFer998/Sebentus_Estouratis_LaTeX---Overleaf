# Sebentus Estouratis: template para uma música

Repo leve para escreveres **uma página** (uma música) no Overleaf.
O cancioneiro completo vive noutro repo, com todas as músicas.

## Como usar

1. Descarrega este repo como .zip.
2. Overleaf: *New Project → Upload Project* e carrega o .zip. Compila sozinho em XeLaTeX
   (o `latexmkrc` trata disso; senão: *Menu → Compiler → XeLaTeX*).
3. Edita **só o `musica.tex`**. O PDF mostra a página tal como vai ficar no cancioneiro.
4. Quando estiver pronta, entrega o `musica.tex` no repo do cancioneiro:
   - copia-o para `musicas/` com o nome da música em minúsculas, sem acentos e com
     hífenes (ex.: `musicas/a-barata.tex`);
   - acrescenta `\input{musicas/a-barata}` no `main.tex` do cancioneiro.

## Sintaxe

```latex
\begin{musica}{Título}{Original}{Adaptação}
\nota{Introdução: D E Am}

Engenha\ac{Am}{ria},
Curso que me envai\ac{E}{de}ce \ac{A7}{}

\nota{Refrão:}
É grande \ac{F#m}{luz} d’acade\ac{Bm}{mia} \nota{2x}

\posicoes{D: xx0232, E: 022100}
\end{musica}
```

- Cada linha do ficheiro é uma linha da página; linha em branco separa estrofes.
- `\ac{Am}{ria}`: acorde sobre a sílaba (sublinhada). `\ac{A7}{}`: acorde sem sílaba.
- `\nota{...}`: texto a vermelho (Refrão, Introdução, 2x, …).
- `\posicoes{...}`: posições dos acordes, no canto inferior direito.
- `#` e `_` escrevem-se diretamente. Para `%`, `&`, `$` usa `\%`, `\&`, `\$`.
- Duas colunas: `\begin{multicols}{2}` … `\end{multicols}`.
- Tablaturas: `\begin{tablatura}` … `\end{tablatura}`; acordes por cima com `\acordestab{   Am   E}`.

## Ficheiros

| Ficheiro | Para quê |
|---|---|
| `musica.tex` | **A tua música** (o único que editas) |
| `main.tex` | Documento mínimo que inclui `musica.tex` |
| `tuna.sty`, `fontes/`, `latexmkrc` | Estilo, fontes e compilador; não mexer (iguais aos do cancioneiro) |
